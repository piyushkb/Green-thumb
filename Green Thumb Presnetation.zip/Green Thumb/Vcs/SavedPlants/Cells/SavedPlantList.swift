

import UIKit

class SavedPlantList: UITableViewCell {

   @IBOutlet weak var plantImage: UIImageView!
   
   
   @IBOutlet weak var plantName: UILabel!
   @IBOutlet weak var plantDate: UILabel!
   @IBOutlet weak var plantTask: UILabel!
}
